// config.ts
// You can change BASE_URL here or use environment variables for more advanced setups
export const BASE_URL = 'https://opencartmobileapp.iextendlabs.com/index.php?route=extension/mobile_app/api/app';
