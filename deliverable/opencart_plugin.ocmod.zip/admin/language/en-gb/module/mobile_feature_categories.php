<?php
// Heading
$_['heading_title']    = 'Mobile Home Page Categories Module';
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Mobile Home Page Categories module!';
$_['text_edit']        = 'Edit Mobile Home Page Categories Module';
$_['text_form']        = 'Mobile Home Page Categories Form';
// Entry
$_['entry_status']     = 'Status';
$_['entry_category']     = 'Categories';
$_['error_permission'] = 'Warning: You do not have permission to modify Mobile Home Page Categories module!';
$_['text_enabled']     = 'Enabled';
$_['text_disabled']    = 'Disabled';    