<?php
// Heading  
$_['heading_title']    = 'Mobile App Trust Badges Module';
$_['text_extension']   = 'Extensions';  
$_['text_success']     = 'Success: You have modified Mobile App Trust Badges module!';
$_['text_edit']        = 'Edit Mobile App Trust Badges Module';
$_['text_form']        = 'Mobile App Trust Badges Form';
// Entry
$_['entry_status']     = 'Status';
$_['error_permission'] = 'Warning: You do not have permission to modify Mobile App Trust Badges module!';
$_['text_enabled']     = 'Enabled'; 
$_['text_disabled']    = 'Disabled';
$_['entry_image']     = 'Image';
$_['entry_title']     = 'Title';
$_['entry_short_description']     = 'Short Description';
$_['text_no_results']  = 'No Badges Added';